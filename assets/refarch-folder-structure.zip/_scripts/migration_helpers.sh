#!/bin/bash
# Helper functions for implementing state migrations for updating terraform modules to newer versions.

function log {
  >&2 echo -e "$@"
}

# find_state_address uses the provided query string to identify the full resource address to use in the state file.
function find_state_address {
  local -r query="$1"

  log "Identifying real state address of $query"
  terragrunt state list \
    | grep -E "$query" || true
}

# strip_bash_color will strip out bash color/bold escape sequences.
function strip_bash_color {
  local -r input="$1"
  # Based on this stack overflow post: https://stackoverflow.com/questions/6534556/how-to-remove-and-all-of-the-escape-sequences-in-a-file-using-linux-shell-sc.
  # None of the sed calls worked to completely strip of the escape sequences by itself, but the following combination worked.
  echo "$input" | cat -v | sed 's/\^\[\[[10]m//g'
}

# Check that the given binary is available on the PATH. If it's not, exit with an error.
function assert_is_installed {
  local -r name="$1"
  local -r help_url="$2"

  if ! command -v "$name" > /dev/null; then
    log "ERROR: The command '$name' is required by this script but is not installed or in the system's PATH. Visit $help_url for instructions on how to install."
    exit 1
  fi
}

# Make sure that the hcledit utility is installed and available on the system.
function assert_hcledit_is_installed {
  assert_is_installed 'hcledit' 'https://github.com/minamijoyo/hcledit#install'
}

# Make sure that the jq utility is installed and available on the system.
function assert_jq_is_installed {
  assert_is_installed 'jq' 'https://stedolan.github.io/jq/download/'
}

# Move resources in terraform state using fuzzy matches.
function fuzzy_move_state {
  local -r original_addr_query="$1"
  local -r new_addr="$2"
  local -r friendly_name="$3"

  log "Checking if $friendly_name needs to be migrated"

  local original_addr
  original_addr="$(find_state_address "$original_addr_query")"

  if [[ -z "$original_addr" ]]; then
    echo "Nothing to change. Skipping state migration."
  else
    echo "Migrating state:"
    echo
    echo "    $original_addr =>"
    echo "      $new_addr"
    echo
    terragrunt state mv "$original_addr" "$new_addr"
  fi
}

# Move resources in terraform state using an import call instead of state mv. This is useful when moving resources
# across aliased resources (e.g., aws_alb => aws_lb).
function fuzzy_import_move_state {
  local -r original_addr_query="$1"
  local -r new_addr="$2"
  local -r resource_basename="$3"
  local -r friendly_name="$4"

  log "Checking if $friendly_name needs to be migrated."
  local original_addr
  original_addr="$(find_state_address "$original_addr_query")"
  if [[ -z "$original_addr" ]]; then
    log "$friendly_name is already migrated. Skipping import."
    return
  fi

  log "$friendly_name needs to be migrated"

  # The following routine extracts the resource ID so that it can be used to import it into the new resource, since the
  # underlying resource type changed.
  log "Idenfitying $friendly_name ID to import into new resource."
  local state
  state="$(terragrunt state show "$original_addr")"
  local state_nocolor
  state_nocolor="$(strip_bash_color "$state")"

  local resource_id
  resource_id="$(
    echo "$state_nocolor" \
      | hcledit attribute get "$resource_basename".id \
      | jq -r '.'
  )"

  if [[ -z "$resource_id" ]]; then
    log "ERROR: could not identify $friendly_name ID to import."
    exit 1
  fi

  log "Importing $friendly_name to new resource:"
  log
  log "    ID:           $resource_id"
  log "    ResourceAddr: $new_addr"
  terragrunt import "$new_addr" "$resource_id"

  log "Removing old $friendly_name state."
  terragrunt state rm "$original_addr"
}
